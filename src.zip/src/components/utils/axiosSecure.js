import axios from "axios";
import { API_BASE_URL } from "../../config/api";
import { navigateTo } from "./navigation";

const axiosSecure = axios.create({
  baseURL: API_BASE_URL,
  withCredentials: true,
});

// Attach access token
axiosSecure.interceptors.request.use((config) => {
  const token = localStorage.getItem("access");
  console.log("📤 Request →", config.url, "Token:", token);
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Handle responses
axiosSecure.interceptors.response.use(
  (res) => {
    console.log("✅ Response", res.status, res.config.url);
    return res;
  },

  async (error) => {
    const original = error.config;
    console.log("❌ API Error:", error.response?.status, original.url);

    // If unauthorized and not retried yet
    if (error.response?.status === 401 && !original._retry) {
      original._retry = true;
      console.log("🔁 Trying refresh token...");

      try {
        // Call refresh API
        const res = await axios.post(
          `${API_BASE_URL}/auth/token/refresh/`,
          {},
          { withCredentials: true }
        );

        console.log("🎉 Refresh Success:", res.data.access);

        // Save new access token
        localStorage.setItem("access", res.data.access);

        // Retry original request with new token
        original.headers.Authorization = `Bearer ${res.data.access}`;
        return axiosSecure(original);

      } catch (err) {
        console.log("💀 Refresh Failed:", err.response?.data);

        // ❗ Only remove access token, do NOT clear entire localStorage
        localStorage.removeItem("access");

        navigateTo("/login");
        return;
      }
    }

    return Promise.reject(error);
  }
);

export default axiosSecure;
