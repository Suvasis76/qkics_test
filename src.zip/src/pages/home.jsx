// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { faHouse, faUsers } from "@fortawesome/free-solid-svg-icons";

function Home({ theme }) {
  const isDark = theme === 'dark';

  // Colors
  const bg = isDark ? 'bg-[#0f0f0f]' : 'bg-[#f5f5f5]';
  const cardBg = isDark ? 'bg-[#2c2c2c]' : 'bg-white';
  const hoverBg = isDark ? 'hover:bg-[#3a3a3a]' : 'hover:bg-[#f0f0f0]';
  const text = isDark ? 'text-[#eaeaea]' : 'text-[#111111]';
  const borderColor = isDark ? 'border-white/15' : 'border-black/10';

  return (
    <div className={`min-h-screen mt-3 ${bg}`}>
      <div className="pt-14 max-w-6xl mx-auto px-4 pb-10 grid grid-cols-12 gap-4">

        {/* LEFT SIDEBAR */}
        <aside className="hidden md:block md:col-span-3 lg:col-span-2">
          <div className={`sticky top-16 space-y-3 text-sm ${text}`}>

            {/* CREATE SPACE BUTTON */}
            <button
              className={`
                w-full flex items-center gap-3 px-4 py-3 rounded-2xl transition-all
                ${cardBg} backdrop-blur-xl
                ${hoverBg} shadow-md hover:shadow-lg
                border ${borderColor}
              `}
            >
              <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-red-500 text-white text-sm font-bold">
                D
              </span>
              <span className="font-semibold">Create Space</span>
            </button>

          

            {/* TOPICS */}
            <div className="mt-6 space-y-1">
              <p className={`text-xs font-bold uppercase tracking-wider ${text}/60 px-4 mb-2`}>Topics</p>
              {["Software Engineering", "Computer Hardware", "Science of Everyday Life", "Travel & Vacation"].map((t) => (
                <button
                  key={t}
                  className={`w-full text-left px-4 py-2.5 rounded-xl transition ${hoverBg} border ${borderColor}`}
                >
                  {t}
                </button>
              ))}
            </div>

          </div>
        </aside>

        {/* CENTER FEED */}
        <main className="col-span-12 md:col-span-6 lg:col-span-7 space-y-5">

          {/* ASK BOX */}
          <section
            className={`rounded-2xl overflow-hidden backdrop-blur-xl shadow-md hover:shadow-lg transition-all ${cardBg} border ${borderColor}`}
          >
            <div className={`px-5 py-4 flex items-center gap-3 text-sm border-b ${borderColor}`}>
              <button className="px-4 py-1.5 rounded-full bg-red-500 text-white text-xs font-semibold shadow-md">
                Add question
              </button>
              <button className={`px-4 py-1.5 rounded-full text-xs transition ${hoverBg}`}>Answer</button>
              <button className={`px-4 py-1.5 rounded-full text-xs transition ${hoverBg}`}>Post</button>
            </div>

            <div className="p-5 flex items-center gap-4">
              <div className="h-10 w-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 shadow-md" />
              <div className={`flex-1 px-5 py-3.5 rounded-2xl shadow-inner text-xs ${isDark ? 'bg-[#3a3a3a] text-[#eaeaea]' : 'bg-[#f0f0f0] text-[#111111]'} border ${borderColor}`}>
                What do you want to ask or share?
              </div>
            </div>
          </section>

          {/* EXAMPLE POSTS */}
          {[1,2].map((post) => (
            <article
              key={post}
              className={`rounded-2xl overflow-hidden backdrop-blur-xl shadow-md hover:shadow-lg transition-all ${cardBg} border ${borderColor}`}
            >
              <header className="p-5 flex items-start gap-4">
                <div className={`h-12 w-12 rounded-full ${post===1 ? 'bg-gradient-to-br from-blue-500 to-cyan-500' : 'bg-gradient-to-br from-emerald-500 to-teal-500'} shadow-md`} />
                <div>
                  <div className={`text-xs ${isDark ? 'text-[#eaeaea]/70' : 'text-[#111111]/70'}`}>
                    <span className={`font-bold ${text}`}>{post===1 ? 'Aditya Patel' : 'Ben Robinson'}</span> • {post===1 ? 'Lived in Mumbai • Oct 10' : 'Updated 3y'}
                  </div>
                  <h2 className={`mt-2 text-lg font-bold ${text}`}>
                    {post===1 ? 'What is a famous short quote?' : 'Can I get a fanless gaming laptop?'}
                  </h2>
                </div>
              </header>

              <div className={`px-6 pb-6 text-xs ${text}`}>
                <p className="text-base leading-relaxed">
                  {post===1 ? 'Did you know butterflies rest when it rains?' : 'When it comes to "fanless", "gaming", and "laptop" — you can pick any two.'}
                </p>
                <div className={`mt-6 h-64 rounded-2xl ${isDark ? 'bg-[#3a3a3a]' : 'bg-[#f0f0f0]'} backdrop-blur-xl shadow-inner flex items-center justify-center text-sm font-medium ${text} border ${borderColor}`}>
                  {post===1 ? 'You’ll fly again when the storm is over.' : 'Static placeholder image'}
                </div>
              </div>
            </article>
          ))}

        </main>

        {/* RIGHT SIDEBAR */}
        <aside className="hidden lg:block lg:col-span-3 space-y-5">

          {/* AD CARD */}
          <div className={`rounded-2xl overflow-hidden backdrop-blur-xl shadow-md hover:shadow-lg ${cardBg} border ${borderColor}`}>
            <div className={`px-5 py-3 text-xs font-bold uppercase tracking-wider ${text}/50`}>
              Advertisement
            </div>
            <div className="p-6">
              <h4 className={`${text} font-bold`}>Grow your business with PayPal</h4>
              <p className={`${text}/70 text-sm mt-1`}>Accept payments from anywhere.</p>
              <button className="mt-4 px-5 py-2 rounded-full bg-red-500 text-white text-sm font-bold shadow-md hover:shadow-lg transition">
                Get Started
              </button>
            </div>
          </div>

          {/* SPACES TO FOLLOW */}
          <div className={`rounded-2xl p-6 backdrop-blur-xl shadow-md hover:shadow-lg ${cardBg} border ${borderColor}`}>
            <h3 className={`text-xs font-bold uppercase tracking-wider ${text}/60 mb-5`}>Spaces to follow</h3>
            <div className="space-y-5">
              {["Software Engineering", "Science of Everyday Life"].map((space) => (
                <div key={space} className="flex items-center gap-4">
                  <div className="h-14 w-14 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 shadow-md ring-1 ring-white/20" />
                  <div className="flex-1">
                    <p className={`font-bold ${text}`}>{space}</p>
                    <p className={`text-xs ${text}/70 mt-1`}>
                      {space.includes("Software") ? "For developers" : "Curious questions"}
                    </p>
                  </div>
                  <button className={`px-5 py-2 rounded-full text-sm font-semibold shadow-md hover:shadow-lg transition ${isDark ? 'bg-[#3a3a3a]' : 'bg-[#f0f0f0]'} border ${borderColor}`}>
                    Follow
                  </button>
                </div>
              ))}
            </div>
          </div>

        </aside>

      </div>
    </div>
  );
}

export default Home;
