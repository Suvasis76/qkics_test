    // src/pages/Profile.jsx
    import { useEffect, useState } from "react";
    import axiosSecure from "../components/utils/axiosSecure";

    function Profile({ theme }) {
    const isDark = theme === "dark";

    const [user, setUser] = useState(null);

    useEffect(() => {
        const fetchUser = async () => {
        try {
            const res = await axiosSecure.get("/auth/me/");
            setUser(res.data);
        } catch (err) {
            console.log("Profile error:", err.response?.data);
        }
        };

        fetchUser();
    }, []);

    if (!user) {
        return (
        <div
            className={`mt-20 text-center ${
            isDark ? "text-white" : "text-black"
            }`}
        >
            Loading...
        </div>
        );
    }

    return (
        <div
        className={`max-w-xl mx-auto mt-20 p-6 rounded-xl shadow ${
            isDark ? "bg-neutral-900 text-white" : "bg-white text-black"
        }`}
        >
        <h2 className="text-2xl font-bold mb-4">My Profile</h2>

        <div className="space-y-2 text-sm">
            <p><strong>ID:</strong> {user.id}</p>
            <p><strong>Username:</strong> {user.username}</p>
            <p><strong>Email:</strong> {user.email || "Not provided"}</p>
            <p><strong>Phone:</strong> {user.phone || "Not provided"}</p>
            <p><strong>User Type:</strong> {user.user_type}</p>
            <p><strong>Status:</strong> {user.status}</p>
            <p><strong>Verified:</strong> {user.is_verified ? "Yes" : "No"}</p>
            <p><strong>Created At:</strong> {user.created_at}</p>
            <p><strong>Updated At:</strong> {user.updated_at}</p>
        </div>
        </div>
    );
    }

    export default Profile;
