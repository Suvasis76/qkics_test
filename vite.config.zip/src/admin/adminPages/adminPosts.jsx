export default function AdminPosts() {
    return (
        <div className="flex items-center justify-center py-20">
            <h1 className="text-2xl font-bold opacity-50">Admin Posts Page - Coming Soon!</h1>
        </div>
    );
}